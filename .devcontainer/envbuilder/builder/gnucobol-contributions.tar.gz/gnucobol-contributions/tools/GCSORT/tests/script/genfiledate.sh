##
##
export dd_infile=../filesin/FDate_Struct.txt
export dd_outfile=../files/FDate.dat
../bin/genfiledate
