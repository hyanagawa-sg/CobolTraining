make clean
make
cp gcsort_gentestcase bin
